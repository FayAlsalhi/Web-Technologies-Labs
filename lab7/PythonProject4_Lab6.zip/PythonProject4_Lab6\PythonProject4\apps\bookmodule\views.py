from django.db.models import Q
from django.shortcuts import render

from .models import Book


def index(request):
    name = request.GET.get("name") or "world!"
    return render(request, "bookmodule/index.html", {"name": name})


def index2(request, val1=0):
    from django.http import HttpResponse
    return HttpResponse("value1 = " + str(val1))


# ── Lab 6: HTML forms & in-memory book search ───────────────────────────────

def _seed_books_if_empty() -> None:
    """
    Lab helper: if the Book table is empty, insert a few sample records.
    This makes /books/search show results immediately without manual DB setup.
    """
    if Book.objects.exists():
        return

    Book.objects.bulk_create(
        [
            Book(
                title="Continuous Delivery",
                author="J.Humble and D. Farley",
                price=120.0,
                edition=1,
            ),
            Book(
                title="Reversing: Secrets of Reverse Engineering",
                author="E. Eilam",
                price=150.0,
                edition=1,
            ),
            Book(
                title="The Hundred-Page Machine Learning Book",
                author="Andriy Burkov",
                price=90.0,
                edition=1,
            ),
        ]
    )


def searchBooks(request):
    """
    GET: render the search form (search.html).
    POST: read keyword + checkbox options, query Book table using Django ORM,
          then render bookList.html.
    URL: /books/search (see libraryproject/urls.py + apps.bookmodule.urls).
    """
    # Ensure there is something to search for in the lab environment.
    _seed_books_if_empty()

    if request.method == "POST":
        # Keyword from <input name="keyword">; strip so spaces alone do not search.
        keyword = (request.POST.get("keyword") or "").strip()
        # Checkboxes only appear in POST when checked; value defaults to "on" in browsers.
        search_in_title = bool(request.POST.get("option1"))
        search_in_author = bool(request.POST.get("option2"))

        # If the student didn't check any checkbox, default to searching in both fields.
        if not search_in_title and not search_in_author:
            search_in_title = True
            search_in_author = True

        queryset = Book.objects.all()

        # If keyword is empty, show all books (useful for lab validation).
        if keyword:
            q = Q()
            if search_in_title:
                q |= Q(title__icontains=keyword)
            if search_in_author:
                q |= Q(author__icontains=keyword)
            queryset = queryset.filter(q)

        return render(
            request,
            "bookmodule/bookList.html",
            {
                "books": queryset,
                "from_search": True,
                "keyword": keyword,
                "search_in_title": search_in_title,
                "search_in_author": search_in_author,
            },
        )

    # GET – show empty search form
    return render(request, "bookmodule/search.html")


def simple_query(request):
    """
    Lab 7 (Models Part 1): simple ORM filter.
    URL: /books/simple/query
    """
    _seed_books_if_empty()
    mybooks = Book.objects.filter(title__icontains="and")
    return render(request, "bookmodule/bookList.html", {"books": mybooks})


def complex_query(request):
    """
    Lab 7 (Models Part 1): complex ORM query using chaining + slicing.
    URL: /books/complex/query
    Requirements:
    - author is not null
    - title contains 'and'
    - edition >= 2
    - exclude price <= 100
    - first 10 rows only
    """
    _seed_books_if_empty()
    mybooks = (
        Book.objects.filter(author__isnull=False)
        .filter(title__icontains="and")
        .filter(edition__gte=2)
        .exclude(price__lte=100)[:10]
    )
    return render(request, "bookmodule/bookList.html", {"books": mybooks})
