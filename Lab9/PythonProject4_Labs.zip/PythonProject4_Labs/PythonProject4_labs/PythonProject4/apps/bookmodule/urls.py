from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("index2/<int:val1>/", views.index2, name="index2"),
    path("search", views.searchBooks, name="searchBooks"),
    path("simple/query", views.simple_query, name="simple_query"),
    path("complex/query", views.complex_query, name="complex_query"),
    # ── Lab 8 ────────────────────────────────────────────────────────────────
    path("lab8/task1", views.lab8_task1, name="lab8_task1"),
    path("lab8/task2", views.lab8_task2, name="lab8_task2"),
    path("lab8/task3", views.lab8_task3, name="lab8_task3"),
    path("lab8/task4", views.lab8_task4, name="lab8_task4"),
    path("lab8/task5", views.lab8_task5, name="lab8_task5"),
    path("lab8/task7", views.lab8_task7, name="lab8_task7"),
    # ── Lab 9 (annotations) ─────────────────────────────────────────────────
    path("lab9/task1", views.lab9_task1, name="lab9_task1"),
    path("lab9/task2", views.lab9_task2, name="lab9_task2"),
    path("lab9/task3", views.lab9_task3, name="lab9_task3"),
    path("lab9/task4", views.lab9_task4, name="lab9_task4"),
    path("lab9/task5", views.lab9_task5, name="lab9_task5"),
    path("lab9/task6", views.lab9_task6, name="lab9_task6"),
]
