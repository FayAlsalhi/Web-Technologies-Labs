# ============================================================
# أضيفي هذا في ملف main/settings.py
# ============================================================

import os  # تأكدي أن هذا السطر موجود في أعلى الملف

# Static files settings - أضيفيها بعد STATIC_URL الموجودة
STATIC_URL = 'static/'

STATICFILES_DIRS = [(os.path.join(BASE_DIR, "apps/static"))]

# ============================================================
# أضيفي هذا في INSTALLED_APPS إذا لم يكن موجوداً
# ============================================================
INSTALLED_APPS = [
    # ... تطبيقاتك الحالية ...
    'apps.bookmodule',
]

# ============================================================
# أضيفي هذا في TEMPLATES - خيار DIRS
# ============================================================
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'apps/templates')],  # <-- هذا السطر
        'APP_DIRS': True,
        # ...
    },
]
