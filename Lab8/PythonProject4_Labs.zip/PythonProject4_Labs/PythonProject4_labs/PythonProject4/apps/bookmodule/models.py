from django.db import models


class Book(models.Model):
    title = models.CharField(max_length=50)
    author = models.CharField(max_length=50)
    price = models.FloatField(default=0.0)
    edition = models.SmallIntegerField(default=1)


# ── Lab 8 (Models Part 2) ────────────────────────────────────────────────────

class Address(models.Model):
    """A simple Address model used by Student via a ForeignKey."""

    city = models.CharField(max_length=100)

    def __str__(self) -> str:
        return self.city


class Student(models.Model):
    """A Student belongs to an Address (city)."""

    name = models.CharField(max_length=100)
    age = models.IntegerField()
    address = models.ForeignKey(Address, on_delete=models.CASCADE, related_name="students")

    def __str__(self) -> str:
        return f"{self.name} ({self.age})"
