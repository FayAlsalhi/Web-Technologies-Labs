from django.db.models import Avg, Count, Max, Min, Q, Sum
from django.shortcuts import render

from .models import Address, Book, Student


def index(request):
    name = request.GET.get("name") or "world!"
    return render(request, "bookmodule/index.html", {"name": name})


def index2(request, val1=0):
    from django.http import HttpResponse
    return HttpResponse("value1 = " + str(val1))


# ── Lab 6: HTML forms & in-memory book search ───────────────────────────────

def _seed_books_if_empty() -> None:
    """
    Lab helper: if the Book table is empty, insert a few sample records.
    This makes /books/search show results immediately without manual DB setup.
    """
    if Book.objects.exists():
        return

    # Lab 8-friendly sample data (created only when the table is empty).
    # Created using Django ORM only (no hardcoded dicts / no bulk lists).
    Book.objects.create(title="Quick Python", author="Ali", price=70, edition=4)
    Book.objects.create(title="Data and AI", author="Sara", price=120, edition=2)
    Book.objects.create(title="Query Design", author="Omar", price=60, edition=5)


def _seed_students_if_empty() -> None:
    """
    Lab helper: if there are no students yet, insert sample addresses + students.
    Needed for Lab 8 task7 (annotate + Count).
    """
    if Student.objects.exists():
        return

    amman, _ = Address.objects.get_or_create(city="Amman")
    irbid, _ = Address.objects.get_or_create(city="Irbid")
    aqaba, _ = Address.objects.get_or_create(city="Aqaba")

    Student.objects.bulk_create(
        [
            Student(name="Ahmad", age=20, address=amman),
            Student(name="Sara", age=21, address=amman),
            Student(name="Lina", age=19, address=irbid),
            Student(name="Omar", age=22, address=irbid),
            Student(name="Yazan", age=23, address=irbid),
            Student(name="Noor", age=18, address=aqaba),
        ]
    )


def searchBooks(request):
    """
    GET: render the search form (search.html).
    POST: read keyword + checkbox options, query Book table using Django ORM,
          then render bookList.html.
    URL: /books/search (see libraryproject/urls.py + apps.bookmodule.urls).
    """
    # Ensure there is something to search for in the lab environment.
    _seed_books_if_empty()

    if request.method == "POST":
        # Keyword from <input name="keyword">; strip so spaces alone do not search.
        keyword = (request.POST.get("keyword") or "").strip()
        # Checkboxes only appear in POST when checked; value defaults to "on" in browsers.
        search_in_title = bool(request.POST.get("option1"))
        search_in_author = bool(request.POST.get("option2"))

        # If the student didn't check any checkbox, default to searching in both fields.
        if not search_in_title and not search_in_author:
            search_in_title = True
            search_in_author = True

        queryset = Book.objects.all()

        # If keyword is empty, show all books (useful for lab validation).
        if keyword:
            q = Q()
            if search_in_title:
                q |= Q(title__icontains=keyword)
            if search_in_author:
                q |= Q(author__icontains=keyword)
            queryset = queryset.filter(q)

        return render(
            request,
            "bookmodule/bookList.html",
            {
                "books": queryset,
                "from_search": True,
                "keyword": keyword,
                "search_in_title": search_in_title,
                "search_in_author": search_in_author,
            },
        )

    # GET – show empty search form
    return render(request, "bookmodule/search.html")


def simple_query(request):
    """
    Lab 7 (Models Part 1): simple ORM filter.
    URL: /books/simple/query
    """
    _seed_books_if_empty()
    mybooks = Book.objects.filter(title__icontains="and")
    return render(request, "bookmodule/bookList.html", {"books": mybooks})


def complex_query(request):
    """
    Lab 7 (Models Part 1): complex ORM query using chaining + slicing.
    URL: /books/complex/query
    Requirements:
    - author is not null
    - title contains 'and'
    - edition >= 2
    - exclude price <= 100
    - first 10 rows only
    """
    _seed_books_if_empty()
    mybooks = (
        Book.objects.filter(author__isnull=False)
        .filter(title__icontains="and")
        .filter(edition__gte=2)
        .exclude(price__lte=100)[:10]
    )
    return render(request, "bookmodule/bookList.html", {"books": mybooks})


# ── Lab 8 (Models Part 2) ────────────────────────────────────────────────────

def lab8_task1(request):
    """
    /books/lab8/task1
    List books with price <= 80 using Q operator.
    """
    _seed_books_if_empty()
    books = Book.objects.filter(Q(price__lte=80))
    return render(request, "bookmodule/bookList.html", {"books": books})


def lab8_task2(request):
    """
    /books/lab8/task2
    edition > 3 AND (title OR author contains 'qu') using & and | with Q.
    """
    _seed_books_if_empty()
    books = Book.objects.filter(
        Q(edition__gt=3) & (Q(title__icontains="qu") | Q(author__icontains="qu"))
    )
    return render(request, "bookmodule/bookList.html", {"books": books})


def lab8_task3(request):
    """
    /books/lab8/task3
    Opposite of task2:
    - no editions higher than 3  (edition <= 3)
    - title/author does NOT contain 'qu'
    Uses ~ operator with Q.
    """
    _seed_books_if_empty()
    books = Book.objects.filter(
        Q(edition__lte=3) & ~(Q(title__icontains="qu") | Q(author__icontains="qu"))
    )
    return render(request, "bookmodule/bookList.html", {"books": books})


def lab8_task4(request):
    """
    /books/lab8/task4
    List books ordered by title using order_by().
    """
    _seed_books_if_empty()
    books = Book.objects.all().order_by("title")
    return render(request, "bookmodule/bookList.html", {"books": books})


def lab8_task5(request):
    """
    /books/lab8/task5
    Display: count, total price, average price, max price, min price using aggregation.
    """
    _seed_books_if_empty()
    stats = Book.objects.aggregate(
        book_count=Count("id"),
        total_price=Sum("price"),
        avg_price=Avg("price"),
        max_price=Max("price"),
        min_price=Min("price"),
    )
    return render(request, "bookmodule/lab8/task5.html", {"stats": stats})


def lab8_task7(request):
    """
    /books/lab8/task7
    Show number of students in each city using annotate + Count.
    """
    _seed_students_if_empty()
    rows = (
        Student.objects.values("address__city")
        .annotate(num_students=Count("id"))
        .order_by("address__city")
    )
    return render(request, "bookmodule/lab8/task7.html", {"rows": rows})
