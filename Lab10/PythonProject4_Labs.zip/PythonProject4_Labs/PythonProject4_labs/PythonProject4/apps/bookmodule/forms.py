from django import forms
from django.utils import timezone

from .models import Book


class BookForm(forms.ModelForm):
    """Lab 9 Part 2 – Django ModelForm with validation for Book CRUD."""

    class Meta:
        model = Book
        fields = [
            "title",
            "price",
            "quantity",
            "pubdate",
            "rating",
            "publisher",
            "authors",
        ]
        widgets = {
            "pubdate": forms.DateTimeInput(
                attrs={"type": "datetime-local"},
                format="%Y-%m-%dT%H:%M",
            ),
            "authors": forms.SelectMultiple(attrs={"size": "8"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["pubdate"].input_formats = [
            "%Y-%m-%dT%H:%M",
            "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%d %H:%M",
            "%Y-%m-%d",
        ]
        if self.instance.pk and self.instance.pubdate:
            dt = timezone.localtime(self.instance.pubdate)
            self.initial["pubdate"] = dt.strftime("%Y-%m-%dT%H:%M")
