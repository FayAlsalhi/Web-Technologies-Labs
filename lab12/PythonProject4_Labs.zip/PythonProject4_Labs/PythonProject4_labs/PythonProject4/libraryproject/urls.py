from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include

import apps.bookmodule.views
import apps.usermodule.views as user_views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', apps.bookmodule.views.index),
    path('index2/<int:val1>/', apps.bookmodule.views.index2),
    # Lab 12 — explicit routes so /users/* always resolves (no include needed)
    path('users/register', user_views.register_view, name='user_register'),
    path('users/login', user_views.login_view, name='user_login'),
    path('users/logout', user_views.logout_view, name='user_logout'),
    path('books/', include('apps.bookmodule.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
