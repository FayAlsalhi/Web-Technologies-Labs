"""Lab 12: require authentication for all lab pages under /books/."""

from urllib.parse import quote

from django.conf import settings
from django.shortcuts import redirect


class RequireLoginForBooksMiddleware:
    """If the path starts with /books/ and the user is anonymous, redirect to LOGIN_URL."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        path = request.path
        prefix = getattr(settings, "BOOKS_LOGIN_REQUIRED_PREFIX", "/books/")
        if path.startswith(prefix) and not request.user.is_authenticated:
            login_url = settings.LOGIN_URL
            return redirect(f"{login_url}?next={quote(request.get_full_path())}")
        return self.get_response(request)
