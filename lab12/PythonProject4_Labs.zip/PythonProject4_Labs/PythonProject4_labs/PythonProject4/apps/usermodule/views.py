from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login, logout
from django.contrib.auth.forms import AuthenticationForm
from django.shortcuts import redirect, render
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.http import require_http_methods

from .forms import RegisterForm


def _safe_next_url(request) -> str:
    next_url = (
        request.POST.get("next")
        or request.GET.get("next")
        or settings.LOGIN_REDIRECT_URL
    )
    if next_url and url_has_allowed_host_and_scheme(
        next_url,
        allowed_hosts={request.get_host()},
        require_https=request.is_secure(),
    ):
        return next_url
    return settings.LOGIN_REDIRECT_URL


@require_http_methods(["GET", "POST"])
def register_view(request):
    """Lab 12 − Task 1: /users/register"""
    if request.user.is_authenticated:
        return redirect(settings.LOGIN_REDIRECT_URL)
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(
                request,
                "You have successfully registered. Please log in.",
            )
            return redirect("user_login")
        messages.error(
            request,
            "Registration could not be completed. Please fix the errors below.",
        )
    else:
        form = RegisterForm()
    return render(
        request,
        "usermodule/register.html",
        {"form": form},
    )


@require_http_methods(["GET", "POST"])
def login_view(request):
    """Lab 12 − Task 2: /users/login"""
    if request.user.is_authenticated:
        return redirect(_safe_next_url(request))
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            messages.success(request, "Login successful.")
            return redirect(_safe_next_url(request))
        messages.error(
            request,
            "Invalid username or password. Please try again.",
        )
    else:
        form = AuthenticationForm()
    next_val = request.POST.get("next") or request.GET.get("next", "")
    return render(
        request,
        "usermodule/login.html",
        {"form": form, "next": next_val},
    )


@require_http_methods(["GET", "POST"])
def logout_view(request):
    """Lab 12 − Task 4: /users/logout"""
    if request.user.is_authenticated:
        logout(request)
        messages.info(request, "You have been signed out.")
    return redirect(settings.LOGOUT_REDIRECT_URL)
