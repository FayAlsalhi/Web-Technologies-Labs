from django.db import models


# ── Lab 9 (Models Part 3) – schema from pre-lab ───────────────────────────────


class Publisher(models.Model):
    name = models.CharField(max_length=200)
    location = models.CharField(max_length=300)

    def __str__(self) -> str:
        return self.name


class Author(models.Model):
    name = models.CharField(max_length=200)
    DOB = models.DateField(null=True)

    def __str__(self) -> str:
        return self.name


class Book(models.Model):
    title = models.CharField(max_length=100)
    price = models.FloatField(default=0.0)
    quantity = models.IntegerField(default=1)
    pubdate = models.DateTimeField()
    rating = models.SmallIntegerField(default=1)

    publisher = models.ForeignKey(
        Publisher, null=True, on_delete=models.SET_NULL, related_name="books"
    )
    authors = models.ManyToManyField(Author, related_name="books")

    def __str__(self) -> str:
        return self.title


# ── Lab 8 (Models Part 2) ────────────────────────────────────────────────────


class Address(models.Model):
    """A simple Address model used by Student via a ForeignKey."""

    city = models.CharField(max_length=100)

    def __str__(self) -> str:
        return self.city


class Student(models.Model):
    """A Student belongs to an Address (city)."""

    name = models.CharField(max_length=100)
    age = models.IntegerField()
    address = models.ForeignKey(Address, on_delete=models.CASCADE, related_name="students")

    def __str__(self) -> str:
        return f"{self.name} ({self.age})"


# ── Lab 10: Forms Part 2 – M2M copy of Lab 8 models (Task 2) ───────────────


class Address2(models.Model):
    """Parallel to Address for Task 2 (many-to-many with Student2)."""

    city = models.CharField(max_length=100)

    def __str__(self) -> str:
        return self.city


class Student2(models.Model):
    """A student may have several addresses; an address may serve many students."""

    name = models.CharField(max_length=100)
    age = models.IntegerField()
    addresses = models.ManyToManyField(
        Address2,
        related_name="students",
        blank=True,
    )

    def __str__(self) -> str:
        return self.name


# ── Lab 10 Task 3: arbitrary model with image upload ────────────────────────


class GalleryImage(models.Model):
    """Example table for practising ImageField + file uploads in forms."""

    title = models.CharField(max_length=150)
    description = models.CharField(max_length=300, blank=True)
    image = models.ImageField(upload_to="lab10/gallery/%Y/%m/")
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self) -> str:
        return self.title
