from datetime import datetime

from django.db.models import (
    Avg,
    Count,
    F,
    FloatField,
    IntegerField,
    Max,
    Min,
    OuterRef,
    Q,
    Subquery,
    Sum,
    Value,
)
from django.db.models.expressions import ExpressionWrapper
from django.db.models.functions import Coalesce
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_http_methods, require_POST
from django.utils import timezone

from .forms import (
    Address2Form,
    AddressForm,
    BookForm,
    GalleryImageForm,
    Student2Form,
    StudentForm,
)
from .models import (
    Address,
    Address2,
    Author,
    Book,
    GalleryImage,
    Publisher,
    Student,
    Student2,
)


def index(request):
    name = request.GET.get("name") or "world!"
    return render(request, "bookmodule/index.html", {"name": name})


def index2(request, val1=0):
    from django.http import HttpResponse

    return HttpResponse("value1 = " + str(val1))


# ── Lab 6: HTML forms & in-memory book search ───────────────────────────────


def _seed_books_if_empty() -> None:
    """
    If there are no books, insert sample Publisher / Author / Book rows
    (Lab 9 schema) so search and older labs still work.
    """
    if Publisher.objects.exists():
        return

    # Orphan Book rows left from pre–Lab-9 schema would block a useful seed.
    Book.objects.all().delete()

    p_oreilly = Publisher.objects.create(
        name="O'Reilly Media", location="Sebastopol, CA, USA"
    )
    p_pearson = Publisher.objects.create(
        name="Pearson Education", location="London, United Kingdom"
    )
    p_nostarch = Publisher.objects.create(
        name="No Starch Press", location="San Francisco, CA, USA"
    )

    a1 = Author.objects.create(name="Ali Hassan", DOB=datetime(1990, 3, 12).date())
    a2 = Author.objects.create(name="Sara Quinn", DOB=datetime(1988, 7, 22).date())
    a3 = Author.objects.create(name="Omar Khalid", DOB=datetime(1992, 11, 5).date())
    a4 = Author.objects.create(name="Lina Ahmad", DOB=datetime(1995, 1, 30).date())

    base = timezone.now().replace(microsecond=0)

    b1 = Book.objects.create(
        title="Quick Python Guide",
        price=70.0,
        quantity=7,
        pubdate=base,
        rating=5,
        publisher=p_oreilly,
    )
    b1.authors.add(a1, a2)

    b2 = Book.objects.create(
        title="Data and AI",
        price=120.0,
        quantity=2,
        pubdate=base.replace(year=base.year - 1),
        rating=3,
        publisher=p_pearson,
    )
    b2.authors.add(a2)

    b3 = Book.objects.create(
        title="Query Design Patterns",
        price=60.0,
        quantity=15,
        pubdate=base.replace(year=base.year - 2),
        rating=4,
        publisher=p_nostarch,
    )
    b3.authors.add(a3)

    b4 = Book.objects.create(
        title="Intro to Django",
        price=45.5,
        quantity=3,
        pubdate=base.replace(year=base.year - 3),
        rating=5,
        publisher=p_oreilly,
    )
    b4.authors.add(a1, a4)

    # Extra rows for richer Lab 9 aggregations / filters
    Book.objects.create(
        title="Advanced ORM",
        price=89.99,
        quantity=4,
        pubdate=base.replace(month=1, day=10),
        rating=4,
        publisher=p_pearson,
    ).authors.add(a3)

    Book.objects.create(
        title="Cheap Pamphlet",
        price=12.0,
        quantity=50,
        pubdate=base.replace(month=6, day=15),
        rating=2,
        publisher=p_nostarch,
    ).authors.add(a4    )


def _seed_student2_if_empty() -> None:
    """Demo rows for Lab 10 Task 2 (Address2 / Student2 M2M)."""
    if Student2.objects.exists():
        return
    amman, _ = Address2.objects.get_or_create(city="Amman")
    irbid, _ = Address2.objects.get_or_create(city="Irbid")
    aqaba, _ = Address2.objects.get_or_create(city="Aqaba")
    s1 = Student2.objects.create(name="Khaled Saleh", age=21)
    s1.addresses.add(amman, irbid)
    s2 = Student2.objects.create(name="Rania Omar", age=20)
    s2.addresses.add(amman)
    s3 = Student2.objects.create(name="Yousef Ali", age=22)
    s3.addresses.add(aqaba, irbid)


def _seed_students_if_empty() -> None:
    if Student.objects.exists():
        return

    amman, _ = Address.objects.get_or_create(city="Amman")
    irbid, _ = Address.objects.get_or_create(city="Irbid")
    aqaba, _ = Address.objects.get_or_create(city="Aqaba")

    Student.objects.bulk_create(
        [
            Student(name="Ahmad", age=20, address=amman),
            Student(name="Sara", age=21, address=amman),
            Student(name="Lina", age=19, address=irbid),
            Student(name="Omar", age=22, address=irbid),
            Student(name="Yazan", age=23, address=irbid),
            Student(name="Noor", age=18, address=aqaba),
        ]
    )


def searchBooks(request):
    _seed_books_if_empty()

    if request.method == "POST":
        keyword = (request.POST.get("keyword") or "").strip()
        search_in_title = bool(request.POST.get("option1"))
        search_in_author = bool(request.POST.get("option2"))

        if not search_in_title and not search_in_author:
            search_in_title = True
            search_in_author = True

        queryset = Book.objects.select_related("publisher").prefetch_related("authors")

        if keyword:
            q = Q()
            if search_in_title:
                q |= Q(title__icontains=keyword)
            if search_in_author:
                q |= Q(authors__name__icontains=keyword)
            queryset = queryset.filter(q).distinct()

        return render(
            request,
            "bookmodule/bookList.html",
            {
                "books": queryset,
                "from_search": True,
                "keyword": keyword,
                "search_in_title": search_in_title,
                "search_in_author": search_in_author,
            },
        )

    return render(request, "bookmodule/search.html")


def simple_query(request):
    _seed_books_if_empty()
    mybooks = (
        Book.objects.filter(title__icontains="and")
        .select_related("publisher")
        .prefetch_related("authors")
    )
    return render(request, "bookmodule/bookList.html", {"books": mybooks})


def complex_query(request):
    """
    Lab 7: adapted to Lab 9 Book (M2M authors, quantity instead of edition).
    """
    _seed_books_if_empty()
    mybooks = (
        Book.objects.filter(authors__isnull=False)
        .filter(title__icontains="and")
        .filter(quantity__gte=2)
        .exclude(price__lte=100)
        .distinct()
        .select_related("publisher")
        .prefetch_related("authors")[:10]
    )
    return render(request, "bookmodule/bookList.html", {"books": mybooks})


# ── Lab 8 (Models Part 2) ────────────────────────────────────────────────────


def lab8_task1(request):
    _seed_books_if_empty()
    books = Book.objects.filter(Q(price__lte=80)).select_related("publisher").prefetch_related(
        "authors"
    )
    return render(request, "bookmodule/bookList.html", {"books": books})


def lab8_task2(request):
    """edition → quantity in Lab 9 schema; authors__name replaces author text."""
    _seed_books_if_empty()
    books = Book.objects.filter(
        Q(quantity__gt=3) & (Q(title__icontains="qu") | Q(authors__name__icontains="qu"))
    ).distinct().select_related("publisher").prefetch_related("authors")
    return render(request, "bookmodule/bookList.html", {"books": books})


def lab8_task3(request):
    _seed_books_if_empty()
    books = Book.objects.filter(
        Q(quantity__lte=3)
        & ~(Q(title__icontains="qu") | Q(authors__name__icontains="qu"))
    ).distinct().select_related("publisher").prefetch_related("authors")
    return render(request, "bookmodule/bookList.html", {"books": books})


def lab8_task4(request):
    _seed_books_if_empty()
    books = Book.objects.all().order_by("title").select_related("publisher").prefetch_related(
        "authors"
    )
    return render(request, "bookmodule/bookList.html", {"books": books})


def lab8_task5(request):
    _seed_books_if_empty()
    stats = Book.objects.aggregate(
        book_count=Count("id"),
        total_price=Sum("price"),
        avg_price=Avg("price"),
        max_price=Max("price"),
        min_price=Min("price"),
    )
    return render(request, "bookmodule/lab8/task5.html", {"stats": stats})


def lab8_task7(request):
    _seed_students_if_empty()
    rows = (
        Student.objects.values("address__city")
        .annotate(num_students=Count("id"))
        .order_by("address__city")
    )
    return render(request, "bookmodule/lab8/task7.html", {"rows": rows})


# ── Lab 9 (Models Part 3 – annotations) ───────────────────────────────────

# Books with rating >= this value are counted as “highly rated” (Task 5).
LAB9_HIGH_RATING = 4


def lab9_task1(request):
    """
    Task 1: Transient field availability_pct = 100 * quantity / total_book_rows
    (same interpretation as the lab example: 7 / 350 → 2%).
    """
    _seed_books_if_empty()
    total = Book.objects.aggregate(n=Count("id"))["n"] or 0
    if total == 0:
        books = Book.objects.none()
    else:
        books = (
            Book.objects.annotate(
                availability_pct=ExpressionWrapper(
                    100.0 * F("quantity") / Value(total, output_field=FloatField()),
                    output_field=FloatField(),
                )
            )
            .select_related("publisher")
            .prefetch_related("authors")
            .order_by("title")
        )
    return render(
        request,
        "bookmodule/lab9/task1.html",
        {"books": books},
    )


def lab9_task2(request):
    """Task 2: All publishers annotated with total book stock (sum of quantity)."""
    _seed_books_if_empty()
    rows = Publisher.objects.annotate(
        total_stock=Coalesce(Sum("books__quantity"), Value(0, output_field=IntegerField()))
    ).order_by("name")
    return render(request, "bookmodule/lab9/task2.html", {"rows": rows})


def lab9_task3(request):
    """
    Task 3: For each publisher, the oldest book (minimum pubdate; tie-break by id)
    — contrast to Task 2 which sums stock.
    """
    _seed_books_if_empty()
    oldest_subq = (
        Book.objects.filter(publisher_id=OuterRef("pk"))
        .order_by("pubdate", "id")
        .values("id")[:1]
    )
    rows = []
    for pub in Publisher.objects.annotate(oldest_id=Subquery(oldest_subq)).order_by("name"):
        if pub.oldest_id is None:
            continue
        book = Book.objects.get(pk=pub.oldest_id)
        rows.append({"publisher": pub, "book": book})
    return render(request, "bookmodule/lab9/task3.html", {"rows": rows})


def lab9_task4(request):
    """Task 4: Per-publisher avg / min / max price."""
    _seed_books_if_empty()
    rows = Publisher.objects.annotate(
        avg_price=Avg("books__price"),
        min_price=Min("books__price"),
        max_price=Max("books__price"),
    ).order_by("name")
    return render(request, "bookmodule/lab9/task4.html", {"rows": rows})


def lab9_task5(request):
    """
    Task 5: Publishers with count of highly rated books (rating >= LAB9_HIGH_RATING).
    """
    _seed_books_if_empty()
    rows = Publisher.objects.annotate(
        highly_rated_count=Count(
            "books", filter=Q(books__rating__gte=LAB9_HIGH_RATING)
        )
    ).order_by("name")
    return render(
        request,
        "bookmodule/lab9/task5.html",
        {"rows": rows},
    )


def lab9_task6(request):
    """
    Task 6: Per publisher, count books with price > 50 and 1 <= quantity < 5.
    """
    _seed_books_if_empty()
    rows = Publisher.objects.annotate(
        filtered_book_count=Count(
            "books",
            filter=Q(books__price__gt=50)
            & Q(books__quantity__lt=5)
            & Q(books__quantity__gte=1),
        )
    ).order_by("name")
    return render(request, "bookmodule/lab9/task6.html", {"rows": rows})


# ── Lab: Django Forms (CRUD) ────────────────────────────────────────────────


def _parse_pubdate_from_post(raw: str):
    """Parse HTML datetime-local value into an aware datetime."""
    raw = (raw or "").strip()
    if not raw:
        return timezone.now()
    try:
        dt = datetime.fromisoformat(raw)
    except ValueError:
        return timezone.now()
    if timezone.is_naive(dt):
        dt = timezone.make_aware(dt, timezone.get_current_timezone())
    return dt


def _lab_crud_context():
    _seed_books_if_empty()
    return {
        "publishers": Publisher.objects.order_by("name"),
        "authors": Author.objects.order_by("name"),
    }


# ----- Part 1: raw HTML (no Django forms) ---------------------------------


def lab9_part1_listbooks(request):
    """Task 1: list books + link to add; edit/delete per book (by id)."""
    _seed_books_if_empty()
    books = (
        Book.objects.all()
        .order_by("id")
        .select_related("publisher")
        .prefetch_related("authors")
    )
    return render(
        request,
        "bookmodule/lab9_part1/listbooks.html",
        {"books": books},
    )


@require_http_methods(["GET", "POST"])
def lab9_part1_addbook(request):
    """Task 2: insert a new book via plain POST data."""
    extras = _lab_crud_context()
    if request.method == "POST":
        title = (request.POST.get("title") or "").strip() or "Untitled"
        try:
            price = float(request.POST.get("price") or 0)
        except ValueError:
            price = 0.0
        try:
            quantity = int(request.POST.get("quantity") or 1)
        except ValueError:
            quantity = 1
        try:
            rating = int(request.POST.get("rating") or 1)
        except ValueError:
            rating = 1
        pubdate = _parse_pubdate_from_post(request.POST.get("pubdate"))
        pid = request.POST.get("publisher") or None
        publisher = Publisher.objects.filter(pk=pid).first() if pid else None
        book = Book.objects.create(
            title=title,
            price=price,
            quantity=quantity,
            pubdate=pubdate,
            rating=rating,
            publisher=publisher,
        )
        ids = request.POST.getlist("authors")
        if ids:
            book.authors.set(Author.objects.filter(pk__in=ids))
        return redirect("lab9_part1_listbooks")
    return render(request, "bookmodule/lab9_part1/addbook.html", extras)


@require_http_methods(["GET", "POST"])
def lab9_part1_editbook(request, book_id: int):
    """Task 3: update selected book (plain HTML)."""
    extras = _lab_crud_context()
    book = get_object_or_404(
        Book.objects.prefetch_related("authors"),
        pk=book_id,
    )
    if request.method == "POST":
        book.title = (request.POST.get("title") or "").strip() or "Untitled"
        try:
            book.price = float(request.POST.get("price") or 0)
        except ValueError:
            book.price = 0.0
        try:
            book.quantity = int(request.POST.get("quantity") or 1)
        except ValueError:
            book.quantity = 1
        try:
            book.rating = int(request.POST.get("rating") or 1)
        except ValueError:
            book.rating = 1
        book.pubdate = _parse_pubdate_from_post(request.POST.get("pubdate"))
        pid = request.POST.get("publisher") or None
        book.publisher = Publisher.objects.filter(pk=pid).first() if pid else None
        book.save()
        ids = request.POST.getlist("authors")
        book.authors.set(Author.objects.filter(pk__in=ids))
        return redirect("lab9_part1_listbooks")
    pub_local = timezone.localtime(book.pubdate)
    extras["book"] = book
    extras["pubdate_value"] = pub_local.strftime("%Y-%m-%dT%H:%M")
    extras["selected_author_ids"] = {a.pk for a in book.authors.all()}
    return render(request, "bookmodule/lab9_part1/editbook.html", extras)


@require_POST
def lab9_part1_deletebook(request, book_id: int):
    """Task 4: delete book by id (POST from list form)."""
    book = get_object_or_404(Book, pk=book_id)
    book.delete()
    return redirect("lab9_part1_listbooks")


# ----- Part 2: Django ModelForm + validation -------------------------------

def lab9_part2_listbooks(request):
    _seed_books_if_empty()
    books = (
        Book.objects.all()
        .order_by("id")
        .select_related("publisher")
        .prefetch_related("authors")
    )
    return render(
        request,
        "bookmodule/lab9_part2/listbooks.html",
        {"books": books},
    )


@require_http_methods(["GET", "POST"])
def lab9_part2_addbook(request):
    _seed_books_if_empty()
    if request.method == "POST":
        form = BookForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("lab9_part2_listbooks")
    else:
        form = BookForm()
    return render(request, "bookmodule/lab9_part2/addbook.html", {"form": form})


@require_http_methods(["GET", "POST"])
def lab9_part2_editbook(request, book_id: int):
    _seed_books_if_empty()
    book = get_object_or_404(Book, pk=book_id)
    if request.method == "POST":
        form = BookForm(request.POST, instance=book)
        if form.is_valid():
            form.save()
            return redirect("lab9_part2_listbooks")
    else:
        form = BookForm(instance=book)
    return render(
        request,
        "bookmodule/lab9_part2/editbook.html",
        {"form": form, "book": book},
    )


@require_POST
def lab9_part2_deletebook(request, book_id: int):
    book = get_object_or_404(Book, pk=book_id)
    book.delete()
    return redirect("lab9_part2_listbooks")


# ── Lab 10: Django Forms Part 2 (fields + M2M + files) ─────────────────────

# ----- Task 1: Student + Address (FK), Django ModelForms --------------------


def lab10_task1_list_students(request):
    _seed_students_if_empty()
    students = Student.objects.select_related("address").order_by("id")
    return render(request, "bookmodule/lab10/task1/students_list.html", {"students": students})


def lab10_task1_list_addresses(request):
    _seed_students_if_empty()
    addresses = Address.objects.order_by("city").prefetch_related("students")
    return render(request, "bookmodule/lab10/task1/addresses_list.html", {"addresses": addresses})


@require_http_methods(["GET", "POST"])
def lab10_task1_add_address(request):
    if request.method == "POST":
        form = AddressForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("lab10_task1_list_addresses")
    else:
        form = AddressForm()
    return render(
        request,
        "bookmodule/lab10/task1/address_form.html",
        {"form": form, "heading": "Add address"},
    )


@require_http_methods(["GET", "POST"])
def lab10_task1_edit_address(request, address_id: int):
    address = get_object_or_404(Address, pk=address_id)
    if request.method == "POST":
        form = AddressForm(request.POST, instance=address)
        if form.is_valid():
            form.save()
            return redirect("lab10_task1_list_addresses")
    else:
        form = AddressForm(instance=address)
    return render(
        request,
        "bookmodule/lab10/task1/address_form.html",
        {"form": form, "heading": f"Edit address #{address_id}"},
    )


@require_POST
def lab10_task1_delete_address(request, address_id: int):
    get_object_or_404(Address, pk=address_id).delete()
    return redirect("lab10_task1_list_addresses")


@require_http_methods(["GET", "POST"])
def lab10_task1_add_student(request):
    _seed_students_if_empty()
    if request.method == "POST":
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("lab10_task1_list_students")
    else:
        form = StudentForm()
    return render(
        request,
        "bookmodule/lab10/task1/student_form.html",
        {"form": form, "heading": "Add student"},
    )


@require_http_methods(["GET", "POST"])
def lab10_task1_edit_student(request, student_id: int):
    _seed_students_if_empty()
    student = get_object_or_404(Student, pk=student_id)
    if request.method == "POST":
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            return redirect("lab10_task1_list_students")
    else:
        form = StudentForm(instance=student)
    return render(
        request,
        "bookmodule/lab10/task1/student_form.html",
        {"form": form, "heading": f"Edit student #{student_id}"},
    )


@require_POST
def lab10_task1_delete_student(request, student_id: int):
    get_object_or_404(Student, pk=student_id).delete()
    return redirect("lab10_task1_list_students")


# ----- Task 2: Student2 + Address2 (M2M) ------------------------------------


def lab10_task2_list_students(request):
    _seed_student2_if_empty()
    students = Student2.objects.prefetch_related("addresses").order_by("id")
    return render(request, "bookmodule/lab10/task2/students_list.html", {"students": students})


def lab10_task2_list_addresses(request):
    _seed_student2_if_empty()
    addresses = Address2.objects.order_by("city").prefetch_related("students")
    return render(request, "bookmodule/lab10/task2/addresses_list.html", {"addresses": addresses})


@require_http_methods(["GET", "POST"])
def lab10_task2_add_address(request):
    if request.method == "POST":
        form = Address2Form(request.POST)
        if form.is_valid():
            form.save()
            return redirect("lab10_task2_list_addresses")
    else:
        form = Address2Form()
    return render(
        request,
        "bookmodule/lab10/task2/address_form.html",
        {"form": form, "heading": "Add address (Task 2 – Address2)"},
    )


@require_http_methods(["GET", "POST"])
def lab10_task2_edit_address(request, address_id: int):
    address = get_object_or_404(Address2, pk=address_id)
    if request.method == "POST":
        form = Address2Form(request.POST, instance=address)
        if form.is_valid():
            form.save()
            return redirect("lab10_task2_list_addresses")
    else:
        form = Address2Form(instance=address)
    return render(
        request,
        "bookmodule/lab10/task2/address_form.html",
        {"form": form, "heading": f"Edit Address2 #{address_id}"},
    )


@require_POST
def lab10_task2_delete_address(request, address_id: int):
    get_object_or_404(Address2, pk=address_id).delete()
    return redirect("lab10_task2_list_addresses")


@require_http_methods(["GET", "POST"])
def lab10_task2_add_student(request):
    _seed_student2_if_empty()
    if request.method == "POST":
        form = Student2Form(request.POST)
        if form.is_valid():
            form.save()
            return redirect("lab10_task2_list_students")
    else:
        form = Student2Form()
    return render(
        request,
        "bookmodule/lab10/task2/student_form.html",
        {"form": form, "heading": "Add student (Task 2 – Student2 + M2M)"},
    )


@require_http_methods(["GET", "POST"])
def lab10_task2_edit_student(request, student_id: int):
    _seed_student2_if_empty()
    student = get_object_or_404(Student2.objects.prefetch_related("addresses"), pk=student_id)
    if request.method == "POST":
        form = Student2Form(request.POST, instance=student)
        if form.is_valid():
            form.save()
            return redirect("lab10_task2_list_students")
    else:
        form = Student2Form(instance=student)
    return render(
        request,
        "bookmodule/lab10/task2/student_form.html",
        {"form": form, "heading": f"Edit Student2 #{student_id}"},
    )


@require_POST
def lab10_task2_delete_student(request, student_id: int):
    get_object_or_404(Student2, pk=student_id).delete()
    return redirect("lab10_task2_list_students")


# ----- Task 3: GalleryImage + file upload -----------------------------------


def lab10_task3_list_gallery(request):
    items = GalleryImage.objects.order_by("-uploaded_at")
    return render(request, "bookmodule/lab10/task3/gallery_list.html", {"items": items})


@require_http_methods(["GET", "POST"])
def lab10_task3_add_gallery(request):
    if request.method == "POST":
        form = GalleryImageForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect("lab10_task3_list_gallery")
    else:
        form = GalleryImageForm()
    return render(
        request,
        "bookmodule/lab10/task3/gallery_form.html",
        {"form": form, "heading": "Upload image"},
    )


@require_http_methods(["GET", "POST"])
def lab10_task3_edit_gallery(request, item_id: int):
    item = get_object_or_404(GalleryImage, pk=item_id)
    if request.method == "POST":
        form = GalleryImageForm(request.POST, request.FILES, instance=item)
        if form.is_valid():
            form.save()
            return redirect("lab10_task3_list_gallery")
    else:
        form = GalleryImageForm(instance=item)
    return render(
        request,
        "bookmodule/lab10/task3/gallery_form.html",
        {"form": form, "heading": f"Edit gallery item #{item_id}"},
    )


@require_POST
def lab10_task3_delete_gallery(request, item_id: int):
    item = get_object_or_404(GalleryImage, pk=item_id)
    if item.image:
        item.image.delete(save=False)
    item.delete()
    return redirect("lab10_task3_list_gallery")
