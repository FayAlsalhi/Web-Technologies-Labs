# Lab 10: Forms Part 2 – Address2, Student2 (M2M), GalleryImage

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("bookmodule", "0003_lab9_models"),
    ]

    operations = [
        migrations.CreateModel(
            name="Address2",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("city", models.CharField(max_length=100)),
            ],
        ),
        migrations.CreateModel(
            name="Student2",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=100)),
                ("age", models.IntegerField()),
            ],
        ),
        migrations.CreateModel(
            name="GalleryImage",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("title", models.CharField(max_length=150)),
                ("description", models.CharField(blank=True, max_length=300)),
                ("image", models.ImageField(upload_to="lab10/gallery/%Y/%m/")),
                ("uploaded_at", models.DateTimeField(auto_now_add=True)),
            ],
        ),
        migrations.AddField(
            model_name="student2",
            name="addresses",
            field=models.ManyToManyField(blank=True, related_name="students", to="bookmodule.address2"),
        ),
    ]
