# Lab 9: Publisher, Author, and Book schema (Models Part 3)

import django.db.models.deletion
import django.utils.timezone
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("bookmodule", "0002_address_student"),
    ]

    operations = [
        migrations.CreateModel(
            name="Publisher",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=200)),
                ("location", models.CharField(max_length=300)),
            ],
        ),
        migrations.CreateModel(
            name="Author",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=200)),
                ("DOB", models.DateField(null=True)),
            ],
        ),
        migrations.RemoveField(
            model_name="book",
            name="author",
        ),
        migrations.RemoveField(
            model_name="book",
            name="edition",
        ),
        migrations.AddField(
            model_name="book",
            name="quantity",
            field=models.IntegerField(default=1),
        ),
        migrations.AddField(
            model_name="book",
            name="pubdate",
            field=models.DateTimeField(default=django.utils.timezone.now),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name="book",
            name="rating",
            field=models.SmallIntegerField(default=1),
        ),
        migrations.AddField(
            model_name="book",
            name="publisher",
            field=models.ForeignKey(
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="books",
                to="bookmodule.publisher",
            ),
        ),
        migrations.AlterField(
            model_name="book",
            name="title",
            field=models.CharField(max_length=100),
        ),
        migrations.AddField(
            model_name="book",
            name="authors",
            field=models.ManyToManyField(related_name="books", to="bookmodule.author"),
        ),
    ]
