from django import forms
from django.utils import timezone

from .models import (
    Address,
    Address2,
    Book,
    GalleryImage,
    Student,
    Student2,
)


class BookForm(forms.ModelForm):
    """Lab 9 Part 2 – Django ModelForm with validation for Book CRUD."""

    class Meta:
        model = Book
        fields = [
            "title",
            "price",
            "quantity",
            "pubdate",
            "rating",
            "publisher",
            "authors",
        ]
        widgets = {
            "pubdate": forms.DateTimeInput(
                attrs={"type": "datetime-local"},
                format="%Y-%m-%dT%H:%M",
            ),
            "authors": forms.SelectMultiple(attrs={"size": "8"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["pubdate"].input_formats = [
            "%Y-%m-%dT%H:%M",
            "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%d %H:%M",
            "%Y-%m-%d",
        ]
        if self.instance.pk and self.instance.pubdate:
            dt = timezone.localtime(self.instance.pubdate)
            self.initial["pubdate"] = dt.strftime("%Y-%m-%dT%H:%M")


# ── Lab 10: Forms Part 2 ────────────────────────────────────────────────────


class AddressForm(forms.ModelForm):
    class Meta:
        model = Address
        fields = ["city"]


class StudentForm(forms.ModelForm):
    """Task 1: one FK address per student."""

    class Meta:
        model = Student
        fields = ["name", "age", "address"]


class Address2Form(forms.ModelForm):
    class Meta:
        model = Address2
        fields = ["city"]


class Student2Form(forms.ModelForm):
    """Task 2: many addresses per student."""

    class Meta:
        model = Student2
        fields = ["name", "age", "addresses"]
        widgets = {
            "addresses": forms.SelectMultiple(attrs={"size": "8"}),
        }


class GalleryImageForm(forms.ModelForm):
    """Task 3: upload image via form."""

    class Meta:
        model = GalleryImage
        fields = ["title", "description", "image"]
