from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("index2/<int:val1>/", views.index2, name="index2"),
    path("search", views.searchBooks, name="searchBooks"),
    path("simple/query", views.simple_query, name="simple_query"),
    path("complex/query", views.complex_query, name="complex_query"),
    # ── Lab 8 ────────────────────────────────────────────────────────────────
    path("lab8/task1", views.lab8_task1, name="lab8_task1"),
    path("lab8/task2", views.lab8_task2, name="lab8_task2"),
    path("lab8/task3", views.lab8_task3, name="lab8_task3"),
    path("lab8/task4", views.lab8_task4, name="lab8_task4"),
    path("lab8/task5", views.lab8_task5, name="lab8_task5"),
    path("lab8/task7", views.lab8_task7, name="lab8_task7"),
    # ── Lab 9 (annotations) ─────────────────────────────────────────────────
    path("lab9/task1", views.lab9_task1, name="lab9_task1"),
    path("lab9/task2", views.lab9_task2, name="lab9_task2"),
    path("lab9/task3", views.lab9_task3, name="lab9_task3"),
    path("lab9/task4", views.lab9_task4, name="lab9_task4"),
    path("lab9/task5", views.lab9_task5, name="lab9_task5"),
    path("lab9/task6", views.lab9_task6, name="lab9_task6"),
    # ── Lab: Django Forms CRUD ────────────────────────────────────────────
    path("lab9_part1/listbooks", views.lab9_part1_listbooks, name="lab9_part1_listbooks"),
    path("lab9_part1/addbook", views.lab9_part1_addbook, name="lab9_part1_addbook"),
    path(
        "lab9_part1/editbook/<int:book_id>",
        views.lab9_part1_editbook,
        name="lab9_part1_editbook",
    ),
    path(
        "lab9_part1/deletebook/<int:book_id>",
        views.lab9_part1_deletebook,
        name="lab9_part1_deletebook",
    ),
    path("lab9_part2/listbooks", views.lab9_part2_listbooks, name="lab9_part2_listbooks"),
    path("lab9_part2/addbook", views.lab9_part2_addbook, name="lab9_part2_addbook"),
    path(
        "lab9_part2/editbook/<int:book_id>",
        views.lab9_part2_editbook,
        name="lab9_part2_editbook",
    ),
    path(
        "lab9_part2/deletebook/<int:book_id>",
        views.lab9_part2_deletebook,
        name="lab9_part2_deletebook",
    ),
    # ── Lab 10: Forms Part 2 ───────────────────────────────────────────────
    # Task 1 – Student + Address (FK)
    path("lab10/task1/students", views.lab10_task1_list_students, name="lab10_task1_list_students"),
    path("lab10/task1/students/add", views.lab10_task1_add_student, name="lab10_task1_add_student"),
    path(
        "lab10/task1/students/edit/<int:student_id>",
        views.lab10_task1_edit_student,
        name="lab10_task1_edit_student",
    ),
    path(
        "lab10/task1/students/delete/<int:student_id>",
        views.lab10_task1_delete_student,
        name="lab10_task1_delete_student",
    ),
    path("lab10/task1/addresses", views.lab10_task1_list_addresses, name="lab10_task1_list_addresses"),
    path("lab10/task1/addresses/add", views.lab10_task1_add_address, name="lab10_task1_add_address"),
    path(
        "lab10/task1/addresses/edit/<int:address_id>",
        views.lab10_task1_edit_address,
        name="lab10_task1_edit_address",
    ),
    path(
        "lab10/task1/addresses/delete/<int:address_id>",
        views.lab10_task1_delete_address,
        name="lab10_task1_delete_address",
    ),
    # Task 2 – Student2 + Address2 (M2M)
    path("lab10/task2/students", views.lab10_task2_list_students, name="lab10_task2_list_students"),
    path("lab10/task2/students/add", views.lab10_task2_add_student, name="lab10_task2_add_student"),
    path(
        "lab10/task2/students/edit/<int:student_id>",
        views.lab10_task2_edit_student,
        name="lab10_task2_edit_student",
    ),
    path(
        "lab10/task2/students/delete/<int:student_id>",
        views.lab10_task2_delete_student,
        name="lab10_task2_delete_student",
    ),
    path("lab10/task2/addresses", views.lab10_task2_list_addresses, name="lab10_task2_list_addresses"),
    path("lab10/task2/addresses/add", views.lab10_task2_add_address, name="lab10_task2_add_address"),
    path(
        "lab10/task2/addresses/edit/<int:address_id>",
        views.lab10_task2_edit_address,
        name="lab10_task2_edit_address",
    ),
    path(
        "lab10/task2/addresses/delete/<int:address_id>",
        views.lab10_task2_delete_address,
        name="lab10_task2_delete_address",
    ),
    # Task 3 – image upload
    path("lab10/task3/gallery", views.lab10_task3_list_gallery, name="lab10_task3_list_gallery"),
    path("lab10/task3/gallery/add", views.lab10_task3_add_gallery, name="lab10_task3_add_gallery"),
    path(
        "lab10/task3/gallery/edit/<int:item_id>",
        views.lab10_task3_edit_gallery,
        name="lab10_task3_edit_gallery",
    ),
    path(
        "lab10/task3/gallery/delete/<int:item_id>",
        views.lab10_task3_delete_gallery,
        name="lab10_task3_delete_gallery",
    ),
]
